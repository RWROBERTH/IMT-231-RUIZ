int esPrimo(int a);

int factorial(int a);

int contarDigitos(int a);